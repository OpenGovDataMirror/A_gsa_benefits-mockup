<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /static-dev/benefits/common/js/jquery.fancybox-1.3.4.js was not found on this server.</p>
<hr>
<address>Apache/2.2.22 (Ubuntu) Server at apps.my.usa.gov Port 443</address>
</body></html>
